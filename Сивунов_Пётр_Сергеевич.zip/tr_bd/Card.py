import pygame


class Card:
    """ Колода карт
            Методы:
            display()
     """
    def __init__(self, suit, value):
        self.suit = suit
        self.value = value
        self.im_card = pygame.image.load(f"Resources/cards/{self.suit}_{self.value}.png").convert_alpha()
        self.im_card = pygame.transform.scale(self.im_card, (self.im_card.get_width(), self.im_card.get_height()))

    def display(self, sc, x, y):
        """Отображение карты"""
        pygame.Surface.blit(sc, self.im_card, (x, y))
