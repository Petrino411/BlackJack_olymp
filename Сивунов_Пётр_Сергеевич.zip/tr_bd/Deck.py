from Card import Card
import random


class Deck:
    """ Колода карт
                Методы:
                deal_card()
                shuffle_cards()
     """
    def __init__(self):
        self.playing_cards = None
        suits = ['Червы', 'Бубны', 'Трефы', 'Пики']
        values = ['2', '3', '4', '5', '6', '7', '8', '9', '10', 'валет', 'дама', 'король', 'туз']
        self.cards = [Card(suit, value) for suit in suits for value in values]
        self.empty_card = Card("рубашка", 0)
        self.shuffle_cards()

    def deal_card(self):
        """Выдача корты"""
        return self.playing_cards.pop()

    def shuffle_cards(self):
        """Перемешивание карты"""
        cards = self.cards.copy()
        random.shuffle(cards)
        self.playing_cards = cards
