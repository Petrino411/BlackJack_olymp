import pygame
from Player import Player
from Deck import Deck
from Hand import Hand
from Button import Button


class Win:
    """ Главное окно
            Методы:
           play_game()
           new_game()
           make_bet(value)
           game_result()
           dealer_step()
           player_step()
           __display_back()
           load()
           message()
           deal_initial_cards()
           display_hand()
           print_hands()
        """
    def __init__(self):
        pygame.init()
        self.width_sc, self.height_sc = 1550, 800
        self.sc = pygame.display.set_mode((self.width_sc, self.height_sc))

        self.btn = Button(self, 650, 10, 250, 50, "Сделать ставку", self.bet_apply)
        self.btn2 = Button(self, 500, 700, 180, 50, "Взять еще", self.player_step)
        self.btn3 = Button(self, 800, 700, 230, 50, "Воздержаться", self.dealer_step)
        self.btn4 = Button(self, 1300, 10, 200, 50, "Новая игра", self.new_game)

        self.player_hand = Hand()
        self.dealer_hand = Hand()
        self.player = Player()

        self.continue_game = False
        self.first_bet = True
        self.second_bet = False
        self.hide_dealer_card = True
        self.running = True
        self.game_res = -2
        self.bet = 0
        self.chips = []

    def play_game(self):
        """Главный цикл игры"""
        loading_message = "Загрузка..."
        self.message(loading_message, (255, 255, 255), 36, self.width_sc // 2, self.height_sc // 2, self.sc)
        pygame.display.update()

        self.deck = Deck()
        self.load()
        self.deal_initial_cards()

        while self.running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False

            self.__display_back()

            if self.game_res != 4:
                for i in self.chips:
                    i.process()

            self.btn.process()
            self.btn4.process()

            self.game_result()

            if self.first_bet and not self.second_bet and self.game_res != 4:
                if self.player.money == 0 and self.continue_game:
                    self.game_res = 4
                else:
                    self.game_res = -2

            self.message(f"Ваш банк: {self.player.money} $", (255, 255, 255), 28, 300, 30, self.sc)

            if self.continue_game:
                self.btn2.process()
                self.btn3.process()

                self.game_res = 0

                self.print_hands(self.hide_dealer_card)

                player_score = self.player_hand.calculate_score()
                dealer_score = self.dealer_hand.calculate_score()

                if player_score == 21:
                    self.game_res = 1
                    self.continue_game = False
                    self.hide_dealer_card = False

                if not self.hide_dealer_card:
                    if player_score > 21:
                        self.game_res = -1
                        self.continue_game = False
                    elif dealer_score > 21 or player_score > dealer_score:
                        self.player.money += self.bet * 2
                        self.game_res = 1
                        self.continue_game = False
                    elif player_score < dealer_score:
                        self.game_res = 2
                        self.continue_game = False
                    else:
                        self.player.money += self.bet
                        self.game_res = 3
                        self.continue_game = False
            else:
                self.game_result()
            pygame.display.update()

    def new_game(self):
        """Начало нового раунда"""
        if self.game_res != 0:
            if self.player.money == 0:
                self.game_res = 4
            self.first_bet = True
            self.second_bet = False
            self.bet = 0
            self.hide_dealer_card = True
            self.deck.shuffle_cards()
            self.player_hand = Hand()
            self.dealer_hand = Hand()
            self.deal_initial_cards()
            self.continue_game = False

    def bet_apply(self):
        """Подтверждение ставки"""
        if self.bet > 0:
            if self.first_bet:
                self.first_bet = False
                self.continue_game = True
                self.second_bet = True
                return
            if self.second_bet:
                self.second_bet = False

    def make_bet(self, value):
        """Ставка"""
        if self.game_res in (-1, 1, 2, 3, 4):
            return
        if (self.first_bet or self.second_bet) and self.player.money - value >= 0:
            try:
                self.bet += self.player.make_bet(value)
            except ValueError:
                return

    def game_result(self):
        """Вывод сообщения о результате игры"""
        if self.game_res == -2:
            self.message("Сделайте ставку", (255, 255, 255), 60, 775, 250, self.sc)
        if self.game_res == -1:
            self.message("Перебор!", (255, 255, 255), 60, 800, 620, self.sc)
            self.print_hands(self.hide_dealer_card)
        elif self.game_res == 1:
            self.message("Поздравляем! Вы выиграли!", (255, 255, 255), 60, 800, 620, self.sc)
            self.print_hands(self.hide_dealer_card)
        elif self.game_res == 2:
            self.message("Вы проиграли", (255, 255, 255), 60, 800, 620, self.sc)
            self.print_hands(self.hide_dealer_card)
        elif self.game_res == 3:
            self.message("Ничья.", (255, 255, 255), 60, 800, 620, self.sc)
            self.print_hands(self.hide_dealer_card)
        elif self.game_res == 4:
            self.message("У вас закончились деньги. Игра окончена.", (255, 255, 255), 60, 800, 620, self.sc)

    def dealer_step(self):
        """Ход крупье"""
        if self.continue_game:
            if self.bet > 0:
                if self.player_hand.calculate_score() <= 21:
                    while self.dealer_hand.calculate_score() < 17:
                        self.dealer_hand.add_card(self.deck.deal_card())
                    self.hide_dealer_card = False

    def player_step(self):
        """Ход игрока"""
        if self.continue_game:
            if self.bet > 0:
                self.player_hand.add_card(self.deck.deal_card())
                if self.player_hand.calculate_score() > 21:
                    self.hide_dealer_card = False

    def __display_back(self):
        """Отображение фона и шапки"""
        pygame.Surface.blit(self.sc, self.background, (0, 70))
        pygame.Surface.blit(self.sc, self.top, (0, 0))

    def load(self):
        """Загрузки изображений фона и фишек"""
        self.background = pygame.image.load("Resources/green.jpg").convert_alpha()
        self.top = pygame.image.load("Resources/doska.png").convert_alpha()
        self.top = pygame.transform.scale(self.top, (1800, 70))
        chips = [5, 10, 100, 500, 1000]
        for i in range(len(chips)):
            self.chips.append(
                Button(self, 600 + 75 * i, 500, 70, 70, str(chips[i]), lambda value=chips[i]: self.make_bet(value),
                       f"Resources/chips/{chips[i]}.png"))

    def message(self, msg, color, size, x, y, sc):
        """Сообщение в окне"""
        font_style = pygame.font.SysFont('arial', size)
        text = font_style.render(msg, True, color)
        text_rect = text.get_rect(center=(x, y))
        sc.blit(text, text_rect)

    def deal_initial_cards(self):
        """Изначальная раздача карт"""
        self.player_hand.add_card(self.deck.deal_card())
        self.player_hand.add_card(self.deck.deal_card())
        self.dealer_hand.add_card(self.deck.deal_card())
        self.dealer_hand.add_card(self.deck.deal_card())

    def display_hand(self, hand, x_start, y_start, hide_card=False):
        """Отображение карт"""
        i = 0
        x_offset = x_start
        y_offset = y_start
        x_threshold = x_start + 400
        for card in hand.cards:
            if x_offset + i * 120 >= x_threshold:
                x_offset = x_start
                y_offset += 200
                i = 0
            if hide_card and i == 0:
                self.deck.empty_card.display(self.sc, x_offset + i * 120, y_offset)
            else:
                card.display(self.sc, x_offset + i * 120, y_offset)
            i += 1

    def print_hands(self, hide_dealer_card=True):
        """Отображение счета и карт"""
        self.message("Ваша рука:", (255, 255, 255), 30, 150, 100, self.sc)
        self.display_hand(self.player_hand, 200, 180)

        self.message(f"Ваш счет: {self.player_hand.calculate_score()}", (255, 255, 255), 30, 400, 100, self.sc)
        self.message("Рука крупье:", (255, 255, 255), 30, 1020, 100, self.sc)

        if hide_dealer_card:
            self.display_hand(self.dealer_hand, 980, 180, hide_card=True)
        else:
            self.display_hand(self.dealer_hand, 980, 180)

        if not hide_dealer_card:
            self.message(f"Счет крупье: {self.dealer_hand.calculate_score()}", (255, 255, 255), 30, 1300, 100, self.sc)
