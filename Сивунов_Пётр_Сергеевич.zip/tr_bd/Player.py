class Player:
    """ Игрок
            Методы:
            make_bet()
     """
    def __init__(self, money=5000):
        self.money = money

    def make_bet(self, value):
        """Сделать ставку"""
        self.money -= value
        if self.money < 0:
            raise ValueError("У вас недостаточно денег")
        else:
            return value
